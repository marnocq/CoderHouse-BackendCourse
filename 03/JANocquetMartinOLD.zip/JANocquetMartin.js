// funcion de espera
const esperar = ret => { for (let i = 0; i < ret * 3e6; i++); }

// muestra las palabras en orden a partir de un texto
const mostrarPalabras = (texto, tiempo, cantidadPalabras, callback) => {
    let cant_palabras = cantidadPalabras
    let palabras = texto.split(" ")    
    for(let i = 0; i < palabras.length; i++){
        console.log(palabras[i])
        cant_palabras++
        esperar(tiempo)
    }
    callback(null, cant_palabras)
}

let texto1 = 'Contrary to popular belief';
let texto2 = 'Lorem Ipsum is not';
let texto3 = 'simply random text';
const tiempo = 500;

mostrarPalabras(texto1, tiempo, 0, (error, totalPalabras) => {
    mostrarPalabras(texto2, tiempo, totalPalabras, (error, totalPalabras) => {
        mostrarPalabras(texto3, tiempo, totalPalabras, (error, totalPalabras) => {
            console.log('Proceso terminado, cantidad de palabras:', totalPalabras);
        });
    });
});